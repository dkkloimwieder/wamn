# Application release chart

The chart renders one WorkloadDeployment per application. The `flow-http` component handles HTTP and the workflow component runs as the workload's `service`.
The chart reads their digest pins from `platform.roles.http.image` and `platform.workflow.image`.
Release planning adds the JetStream interface grant for the application's project stream and its `evt.<org>.<env>.<project>.>` subjects.

See [platform artifacts](../../../docs/operations/building.md#platform-artifacts) and [workflow execution](../../../docs/architecture/execution.md#workflows).
